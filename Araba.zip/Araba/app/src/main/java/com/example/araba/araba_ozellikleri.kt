package com.example.araba

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle

class araba_ozellikleri : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_araba_ozellikleri)
    }
}